export default function(){
    return (
        <h4>Welcome To dynamic Routing</h4>
    )
}