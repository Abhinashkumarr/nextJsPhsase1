export async function getServerSideProps() {
    try {

      // const res = await fetch('https://jsonplaceholder.typicode.com/users')
      const res = await fetch('https://hellomentor.in/api/v4/get-all-countries');
      const data = await res.json(); 
      console.log(data,"hellomentor");

      return {
        props: {
          todos: data.data, 
        }
      };
    } catch (error) {
      console.error("Error fetching data:", error);
      return {
        props: {
          todos: null, 
        }
      };
    }
  }
  
  function ServerSideRender({ todos }) {
    if (!todos) {
      return <div>Error fetching data</div>;
    }
  
    if (!Array.isArray(todos)) {
      return <div>Invalid data format</div>;
    }
  
    return (
      <div>
        {todos.map((ele) => {
          return (
            <div key={ele.country_id}>
              {ele.country_name}
            </div>
          );
        })}
      </div>
    );
  }
  
  export default ServerSideRender;
  