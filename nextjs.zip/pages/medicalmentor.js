export default function(){
    return (
        <h4>hii medical mentor</h4>
    )
}